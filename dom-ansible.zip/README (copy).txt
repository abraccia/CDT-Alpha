Dominic Bonanno
12 Sep 2025
db9063@g.rit.edu


No special setup is required. Ansible will install postfix. SSH may be required if 
this is modified to work with a remote mail server. 
